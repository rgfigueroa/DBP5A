from django.shortcuts import render
from django.shortcuts import redirect
from .forms import Formulario
from .models import Contacto

def home_view(request):
	f = Formulario(request.POST or None)
	if request.method == 'POST':
		if f.is_valid():
			datos = f.cleaned_data
			c = Contacto()
			c.nombres = datos.get("nombres")
			c.apellidos = datos.get("apellidos")
			c.cedula = datos.get("cedula")
			c.email = datos.get("email")
			if c.save() != True:
				print('Imprimo en pantalla y guardo data en BD')
				print(f.cleaned_data)
				return redirect(about_view)
	context = {
		"form":f,
	}
	return render(request,"home.html",context)

def contact_view(request):
	return render(request,"contact.html",{})

def about_view(request):
	return render(request,"about.html",{})

def demo_view(request):
	return render(request,"demo.html",{})