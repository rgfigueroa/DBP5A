from django.contrib import admin
from .models import Contacto

class AdminContacto(admin.ModelAdmin):
	list_display = ["__str__","nombres","apellidos","cedula","email"]
	#search_fields = ["email"]
	#list_editable = ["nombres","apellidos"]
	list_filter = ["nombres"]
  
	
	class Meta(object):
		model = Contacto

admin.site.register(Contacto,AdminContacto)