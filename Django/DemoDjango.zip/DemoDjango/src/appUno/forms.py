from django import forms
from .models import Contacto

class Formulario(forms.ModelForm):
	class Meta:
		model = Contacto
		fields=["nombres", "apellidos","cedula","email"]