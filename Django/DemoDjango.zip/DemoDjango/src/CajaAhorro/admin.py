from django.contrib import admin
from .models import Cuenta
from .models import Transaccion
from .models import Cliente

class AdminCuenta(admin.ModelAdmin):
	list_display = ["__str__","idCliente","propietario","numero","tipo"]
	class Meta(object):
		model = Cuenta

class AdminCliente(admin.ModelAdmin):
	list_display = ["__str__","nombre","direccion"]
	class Meta(object):
		model = Cliente

class AdminTransaccion(admin.ModelAdmin):
	list_display = ["__str__","monto","descripcion"]
	class Meta(object):
		model = Transaccion		

admin.site.register(Cuenta, AdminCuenta)
admin.site.register(Transaccion, AdminTransaccion)
admin.site.register(Cliente, AdminCliente)