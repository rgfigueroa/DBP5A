from django.db import models

class Transaccion(models.Model):	
	monto=models.DecimalField(max_digits=10, decimal_places=2)
	descripcion=models.CharField(max_length=30)
	def __str__(self):
		return self.monto

class Cliente(models.Model):
	nombre=models.CharField(max_length=30)
	direccion=models.CharField(max_length=30)
	def __str__(self):
		return self.nombre

class Cuenta(models.Model):
	listaTipoCuenta = (
		('a', 'ahorro'),
		('c', 'corriente'),
	)
	idCliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, default="")
	propietario=models.CharField(max_length=30)
	numero=models.CharField(max_length=30)	
	tipo = models.CharField(max_length=30, choices=listaTipoCuenta, default="")

	def __str__(self):
		return self.propietario
