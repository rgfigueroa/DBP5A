from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def home_view(*args, **kwargs):
	return HttpResponse("<h1>Pagina Principal del Sistema AppUno Home</h1>")

def contact_view(*args,**kwargs):
	return HttpResponse("<h1>Pagina de Contacto para el Sistema AppUno</h1>")

def ejemplo(*args,**kwargs):
	return HttpResponse("<h1>Pagina de Ejemplo para el Sistema AppUno</h1>Reproductor de video")

def about(*args,**kwargs):
	return HttpResponse("<h1>Pagina about</h1>")