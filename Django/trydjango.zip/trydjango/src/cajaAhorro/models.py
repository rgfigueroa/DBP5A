from django.db import models

# Create your models here.

class Cuenta(models.Model):
	
	propietario=models.CharField(max_length=30,blank=True)
	numero=models.CharField(max_length=30)
	

def __str__(self):
	return self.propietario
