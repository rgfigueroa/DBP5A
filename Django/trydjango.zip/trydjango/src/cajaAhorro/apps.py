from django.apps import AppConfig


class CajaahorroConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cajaAhorro'
