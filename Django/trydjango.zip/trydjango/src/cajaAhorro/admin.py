from django.contrib import admin
from .models import Cuenta

# Register your models here.



# Register your models here.

class AdminCuenta(admin.ModelAdmin):
	list_display = ["__str__","propietario","numero"]
	class Meta(object):
		model = Cuenta

admin.site.register(Cuenta,AdminCuenta)
		
